 //run the function when doc is loaded
 // <script type="text/javascript">
		$(document).ready(function(){

			$('#one').hover(function(){
				// $(this).css("visibility" ,"hidden");
				$(this).attr("src", "suitback.jpg");
				},
				function(){   

				$(this).attr("src", "suitfront.jpg");
				}

			);

				$('#two').hover(function(){
				// $(this).css("visibility" ,"hidden");
				$(this).attr("src", "ironback.jpg");
				},
				function(){   

				$(this).attr("src", "ironfront.jpg");
				}

			);

					$('#three').hover(function(){
				// $(this).css("visibility" ,"hidden");
				$(this).attr("src", "ironback.jpg");
				},
				function(){   

				$(this).attr("src", "ironfront.jpg");
				}

			);

						$('#three').hover(function(){
				// $(this).css("visibility" ,"hidden");
				$(this).attr("src", "suit2back.jpg");
				},
				function(){   

				$(this).attr("src", "suit2front.jpg");
				}

			);

								$('#four').hover(function(){
				// $(this).css("visibility" ,"hidden");
				$(this).attr("src", "suit3back.jpg");
				},
				function(){   

				$(this).attr("src", "suit3front.jpg");
				}

			);


 		});	
 		
	// </script>
