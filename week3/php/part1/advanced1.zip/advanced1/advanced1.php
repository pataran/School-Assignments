<!DOCTYPE HTML>
<hmtl lang="en-US">
	<head>
		<meta charset="UTF-8"
		<title></title><br>
		<link rel="stylesheet" type="text/css" href="css.css">
	</head>
<body>
<h2>Advanced1</h2>


<?php
$users = array( 
   array('first_name' => 'Michael', 'last_name' => ' Choi '),
   array('first_name' => 'John', 'last_name' => 'Supsupin'),
   array('first_name' => 'Mark', 'last_name' => ' Guillen'),
   array('first_name' => 'KB', 'last_name' => 'Tonel') 
); 
echo "<table>";
echo "<tr id=head><td>First_Name</td><td>Last_Name</td><td>Full Name in upper case</td><td>Length of Name</td></tr>";
// echo "<tr><td>User#</td><td>First Name</td><td>Last Name</td><td>Full Name in UpperCase</td><td>Length of Name</td></tr>";
foreach($users as $user)
	{
		$user['first_name'] = trim($user['first_name']);
		$user['last_name'] = trim($user['last_name']);

		$namecaps =trim(strtoupper($user['first_name'] . " " . $user['last_name']));
		

		$namelength = strlen($user['first_name'] . $user['last_name']);

		echo "<tr><td>" . $user['first_name'] . "</td><td>" . $user['last_name'] . "</td><td>" . $namecaps . "</td><td>" .$namelength . "</td></tr>";
		
	
		
	

	}
	

echo "</table>";
			
?>

</body>
</html>