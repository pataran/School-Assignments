<?php
	session_start();	


	require("connection.php");




		$query_fields = "SELECT * FROM lead_gen_business.leads WHERE first_name LIKE '{$_POST['name']}%' OR last_name LIKE '{$_POST['name']}%'"; 
		$fields = fetch_all($query_fields);
		var_dump($_POST);

		$data = array();
		
		$html = NULL;
		
		$_SESSION['fields'] = $fields;


		$html = "<table border= 1> 	
		</thead>	
			<tr>
				<th>leads_id</th>
				<th>first name</th>
				<th>last name</th>
				<th>registered datetime</th>
				<th>email</th>
			</tr>
	    </thead>			
		<tbody>";

		foreach($fields as $user)
		{
			$html .= "

			<tr>
				<td>{$user['leads_id']}</td>
				<td>{$user['first_name']}</td>
				<td>{$user['last_name']}</td>
				<td>{$user['registered_datetime']}</td>
				<td>{$user['email']}</td>
				
			</tr>
			";
		}

		$html .= "
		</tbody>
		</table>";	
		$data['html'] = $html;
		// echo json_encode($data);	
		
?>


				


